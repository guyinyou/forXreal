using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandPoints : MonoBehaviour
{
    public Vector3 RotationOffset;
    public List<Transform> HandJoint;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
