using System;
using NRKernal;
using UnityEngine;
using UnityEngine.UI;

public class ObjectController : MonoBehaviour
{    
    public Test test;
    public GameObject Mouse;
    public Text showDetial;
    public GameObject quad;
    public GameObject hitPoint;
    // Start is called before the first frame update
    void Start()
    {
        prevPosition = Mouse.transform.position;
    }

    // Update is called once per frame
    private Vector3 prevPosition;
    float a = 100;
    float b = 99;
    void Update()
    {
        UpdateMouse();

        UpdateHands();

        // float diffX = Mouse.transform.position.x - prevPosition.x;
        // float diffY = Mouse.transform.position.y - prevPosition.y;
        // prevPosition = Mouse.transform.position;

        // if(Math.Abs(diffX) > 10 || Math.Abs(diffY) > 10 || (diffX == 0 && diffY == 0)) {
        //     return;
        // }
        
        // a += diffY * 10;
        // a = Math.Min(200, Math.Max(0, a));
        // float progress = a * 0.5f;
        // transform.position = new Vector3(0, 0, ((progress * progress - 2500) * 0.01f));

        // b += diffX * 10;
        // b = Math.Min(299, Math.Max(0, b));
        // progress = b;
        // float bl = (progress * 0.01f + 0.01f);
        // transform.localScale = new Vector3(bl, bl, 1);

        // // float z = transform.position.z;
        // // z += diffY * 10;
        // // z = Math.Min(30, Math.Max(-25, z));
        // // transform.position = new Vector3(0, 0, z);

        // // float bl = transform.localScale.x;
        // // bl += diffX * 0.1f;
        // // bl = Math.Min(2f, Math.Max(0.1f, bl));
        // // transform.localScale = new Vector3(bl, bl, 1);


        // // Debug.Log("diffX: " + diffX + ", diffY" + diffY);
        // // Debug.Log("X: " + diffX + ", Y" + transform.position.z + diffY);
        // if (showDetial != null) {
        //     showDetial.text = "距离: " + (Math.Round(transform.position.z * 1000) / 1000f) + "\n大小: " + (Math.Round(transform.localScale.x * 1000) / 1000f) ;
        // }
    }
    private void UpdateMouse() {
        // Quad的平面信息
        Vector3 quadPosition = quad.transform.position;
        Vector3 quadNormal = quad.transform.forward;

        // 摄像机信息
        Vector3 cameraPosition = Camera.main.transform.position;
        Vector3 cameraForward = Camera.main.transform.forward;

        // 平面常数 D
        float D = -(quadNormal.x * quadPosition.x + quadNormal.y * quadPosition.y + quadNormal.z * quadPosition.z);

        // 计算 t
        float numerator = -(quadNormal.x * cameraPosition.x + quadNormal.y * cameraPosition.y + quadNormal.z * cameraPosition.z + D);
        float denominator = quadNormal.x * cameraForward.x + quadNormal.y * cameraForward.y + quadNormal.z * cameraForward.z;

        if (denominator == 0) // 平行
        {
            hitPoint.SetActive(showhitPoint && false);
        }
        else
        {
            // 比例因子
            float t = numerator / denominator;

            // 交点
            Vector3 hitPointPos = cameraPosition + t * cameraForward;

            // hitPointPos.z = 0;
            hitPoint.transform.position = hitPointPos;

            float width = Math.Abs(quad.transform.localScale.x);
            float heigh = Math.Abs(quad.transform.localScale.y);

            Vector3 localHitPointPos = SmoothPosition(hitPoint.transform.localPosition);
            float xbl = localHitPointPos.x / width;
            float ybl = localHitPointPos.y / heigh;

            xbl *= 1.25f;
            ybl *= 1.25f;
            localHitPointPos.x = xbl * width;
            localHitPointPos.y = ybl * heigh;
            hitPoint.transform.localPosition = localHitPointPos;

            
            if (localHitPointPos.x < -width * 0.5f || localHitPointPos.x > width * 0.5f
                || localHitPointPos.y < -heigh * 0.5f || localHitPointPos.y > heigh * 0.5f) {
                    hitPoint.SetActive(showhitPoint && false);
            } else {
                hitPoint.SetActive(showhitPoint && true);
            }
        }
    }
    private Vector3 prevPos = Vector3.zero;
    private Vector3 SmoothPosition(Vector3 pos) {
        Vector3 diff = pos - prevPos;
        float diffFloat = diff.sqrMagnitude;
        float bl = 1f;
        // if (diffFloat < 15) {
        //     bl = 0;
        // } else if (diffFloat < 30) {
        //     bl = 0.25f;
        // } else if (diffFloat < 60) {
        //     bl = 0.5f;
        // } else if (diffFloat < 120) {
        //     bl = 0.75f;
        // } else {
        //     bl = 1f;
        // }
        Vector3 ret = prevPos + diff * bl;
        prevPos = ret;
        return ret;
    }
    bool pinch = false;
    int countdown = 6;
    bool showhitPoint = true;
    private void UpdateHands() {
        var lHandState = NRInput.Hands.GetHandState(HandEnum.LeftHand);
        var rHandState = NRInput.Hands.GetHandState(HandEnum.RightHand);
        // Debug.Log(lHandState);
        // Debug.Log(rHandState);
        if (lHandState == null && rHandState == null) {
            return;
        }
        if (!lHandState.isTracked && !rHandState.isTracked) {
            showhitPoint = false;
        } else {
            showhitPoint = true;
        }
            
        bool tmpPinch = false;
        if (lHandState != null && lHandState.currentGesture == HandGesture.Pinch){
            tmpPinch = true;
        }
        if (rHandState != null && rHandState.currentGesture == HandGesture.Pinch){
            tmpPinch = true;
        }
        if (tmpPinch) {
            countdown--;
            hitPoint.transform.localScale = new Vector3(25 * 0.8f, 25 * 0.8f, 12.5f * 0.8f);
        } else {
            countdown = 6;
            hitPoint.transform.localScale = new Vector3(50 * 0.8f, 50 * 0.8f, 25 * 0.8f);
        }
        if (countdown > 0) {
            tmpPinch = false;
        }
        
            float x = hitPoint.transform.localPosition.x;
            float y = -hitPoint.transform.localPosition.y;
        
        if (pinch != tmpPinch) {
            Debug.Log("Unity: " + "change tmpPinch");
            AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            AndroidJavaClass clickSimulatorClass = new AndroidJavaClass("com.pub.dou.ClickSimulator");

            if (tmpPinch) {
                Debug.Log("Unity: " + "change tmpPinch 0");
                startX = x;
                startY = y;
                timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            } else {
                Debug.Log("Unity: " + "change tmpPinch 1");
                long duration = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - timestamp;
                // clickSimulatorClass.CallStatic("simulateClick", activity, x, y, Math.Abs(quad.transform.localScale.x), Math.Abs(quad.transform.localScale.y));
                clickSimulatorClass.CallStatic("simulateMove", activity, startX, startY, Math.Abs(quad.transform.localScale.x), Math.Abs(quad.transform.localScale.y), x, y, duration);
            }
            // Focus();
        }
        pinch = tmpPinch;
    }
    float startX = 0;
    float startY = 0;
    long timestamp = 0;
    public static int GetScreenRotation()
    {
        using (AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            using (AndroidJavaClass helper = new AndroidJavaClass("com.pub.dou.ScreenRotationHelper"))
            {
                return helper.CallStatic<int>("getScreenRotation", activity); // 调用 getScreenRotation 方法
            }
        }
    }

    public void ChangePosition(string msg){
        string[] parameters = msg.Split(',');
        float x = float.Parse(parameters[0]);
        float y = float.Parse(parameters[1]);
        float z = float.Parse(parameters[2]);
        transform.position = new Vector3(x, y, z);
        NRFrame.SetFocusDistance(transform.position.magnitude);
        Debug.Log("Unity: recv position {" + x + ", " + y + ", " + z + "}");
    }

    public void ChangeScale(string msg){
        float bl = float.Parse(msg);
        transform.localScale = new Vector3(bl, bl, 1);
        Debug.Log("Unity: recv scale {" + bl + "}");
    }

    public void Focus(){
        var poseTracker = NRSessionManager.Instance.NRHMDPoseTracker;
        poseTracker.ResetWorldMatrix(true);
        Debug.Log("Unity: Focus");

        // 获取当前 transform 下的子对象 Cube
        Transform cubeTransform = transform.Find("Cube");
        
        // 检查是否找到了子对象
        if (cubeTransform != null)
        {
            // 将子对象设置为不可见
            cubeTransform.gameObject.SetActive(!cubeTransform.gameObject.activeSelf);
            transform.Find("GameObject").Find("BackGround").gameObject.SetActive(cubeTransform.gameObject.activeSelf);
        }
        else
        {
            Debug.LogError("Cube not found!");
        }
    }

    public void OnDistanceScrollbar(Scrollbar scrollbar){
        float progress = scrollbar.value * 200;
        double d = progress * 0.5;
        double value = ((d * d - 2500) * 0.01);
        ChangePosition("0,0," + value);
        Debug.Log(value);
    }

    public void OnScaleScrollbar(Scrollbar scrollbar){
        float progress = scrollbar.value * 299;
        double value = progress * 0.01f + 0.01f;
        ChangeScale("" + value);
        Debug.Log(value);
    }

    public void To0dofStable(){
        Debug.Log("Unity: To0dofStable");
        var hmdPoseTracker = NRSessionManager.Instance.NRHMDPoseTracker;
        NRSessionManager.Instance.NRHMDPoseTracker.ChangeTo0DofStable((result) =>
        {
            NRDebugger.Info("[ChangeModeController] ChangeTo0DofStable result:" + result.success);
        });
    }
    public void To3dof(){
        Debug.Log("Unity: To3dof");
        var hmdPoseTracker = NRSessionManager.Instance.NRHMDPoseTracker;
        NRSessionManager.Instance.NRHMDPoseTracker.ChangeTo3Dof((result) =>
        {
            NRDebugger.Info("[ChangeModeController] ChangeTo3Dof result:" + result.success);
        });
    }
    public void To6dof(){
        Debug.Log("Unity: To6dof");
        var hmdPoseTracker = NRSessionManager.Instance.NRHMDPoseTracker;
        NRSessionManager.Instance.NRHMDPoseTracker.ChangeTo6Dof((result) =>
        {
            NRDebugger.Info("[ChangeModeController] ChangeTo6Dof result:" + result.success);
        });
    }
    public void MoveTaskToBack(){
        Debug.Log("Unity: MoveTaskToBack");
        AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
        AndroidJavaClass tools = new AndroidJavaClass("com.pub.dou.Tools");
        tools.CallStatic("moveTaskToBack", activity);
    }
}
