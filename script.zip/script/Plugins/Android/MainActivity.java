package com.pub.dou;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;

import java.io.PrintWriter;
import java.io.StringWriter;

import static com.pub.dou.Tools.exception2String;

public class MainActivity extends Activity {

    private ServiceConnection connection = new ServiceConnection() {

        //重写onServiceConnected()方法和onServiceDisconnected()方法
        //在Activity与Service建立关联和解除关联的时候调用
        @Override
        public void onServiceDisconnected(ComponentName name) {

        }

        //在Activity与Service建立关联时调用
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            try {
                Log.d("Unity", "onServiceConnected: " + name + ", " + iBinder);
                Log.d("Unity", "iInterface: " + iBinder.getInterfaceDescriptor());
                com.pub.dou.Tools.reflectLaunchManager = new com.pub.dou.ReflectLaunchManager(iBinder);
//                reflectLaunchManager.requestLaunchActivityWithSurface(new ComponentName("tv.danmaku.bilibilihd", "tv.danmaku.bili.MainActivityV2"), 1080, 1920, null);
            } catch (Exception e) {
                Log.e("Unity", "onServiceConnected error : " + exception2String(e));
            }
            //通过Intent指定服务端的服务名称和所在包，与远程Service进行绑定
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Button mButton0;
        {
            mButton0 = new Button(this);
            FrameLayout.LayoutParams buttonParams = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            buttonParams.gravity = Gravity.CENTER;
            buttonParams.topMargin = 0;
            mButton0.setLayoutParams(buttonParams);
            mButton0.setText("connect");
            mButton0.setEnabled(true);
            mButton0.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String string3 = "ai.nreal.nebula.service";
                    ComponentName componentName = new ComponentName(string3, "ai.nreal.nebula.service.LaunchService");
                    Intent intent = new Intent();
                    intent.setClassName(componentName.getPackageName(), componentName.getClassName());
                    //需要通过setPackage()方法指定包名
                    intent.setPackage("ai.nreal.nebula.display");
                    bindService(intent, connection, Context.BIND_AUTO_CREATE);
                }
            });
        }

        Button mButton1;
        {
            mButton1 = new Button(this);
            FrameLayout.LayoutParams buttonParams = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            buttonParams.gravity = Gravity.CENTER;
            buttonParams.topMargin = 200;
            mButton1.setLayoutParams(buttonParams);
            mButton1.setText("launch");
            mButton1.setEnabled(true);
            mButton1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    com.pub.dou.Tools.launchActivityOnVirtualDisplay(getApplicationContext(),"tv.danmaku.bilibilihd");
                }
            });
        }

        // 创建一个 FrameLayout，并添加按钮和 SurfaceView
        FrameLayout layout = new FrameLayout(this);
        layout.addView(mButton0);
        layout.addView(mButton1);
        setContentView(layout);

        com.pub.dou.Tools.setCurrentActivity(this);
//        com.pub.dou.Tools.init();

    }
}
