package com.pub.dou;
import android.app.Activity;
import android.app.ActivityOptions;
import android.app.FragmentManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import com.unity3d.player.UnityPlayer;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;

public class Tools {
    private static Activity currentActivity;

    static {
        currentActivity = UnityPlayer.currentActivity;
    }

    public static com.pub.dou.ReflectLaunchManager reflectLaunchManager = null;

    public static void setCurrentActivity(Activity activity) {
        currentActivity = activity;
    }

    public static boolean init() {
        // 启动前台服务
        currentActivity.startForegroundService(new Intent(currentActivity, com.pub.dou.MyForegroundService.class));

        // 请求屏幕捕获权限
        requestScreenCapturePermission();
        return true;
    }

    public static void startOnVirtualDisplay(Context context, MediaProjection mediaProjection, String pkgName) {
        PackageManager pm = context.getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(pkgName);
        ActivityInfo orderActivityInfo = null;
        if (intent != null) {
            ResolveInfo resolveInfo = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
            orderActivityInfo = resolveInfo.activityInfo;
            String mainActivity = orderActivityInfo.name;
            String packageName = orderActivityInfo.packageName;
            Log.d("Unity", "MainActivity: " + mainActivity);
            Log.d("Unity", "PackageName: " + packageName);
        }
        Log.d("Unity", "intent: " + intent);
        Log.d("Unity", "createVitualDisplay: " + pkgName);

//        try {
//            // 获取ExampleClass的Class对象
//            Class<?> clazz = Class.forName("ai.nreal.nebula.service.LocalLaunchManager");
//
//            // 获取staticMethod方法的Method对象
//            Method method = clazz.getDeclaredMethod("getInstance");
//
//            // 调用静态方法并获取返回的对象
//            Object result = method.invoke(null);
//            // 打印结果
//            Log.d("Unity", "LocalLaunchManager getInstance : " + result);
//
//        } catch (Exception e) {
//            StringWriter sw = new StringWriter();
//            PrintWriter pw = new PrintWriter(sw);
//            e.printStackTrace(pw);
//            String stackTrace = sw.toString();
//
//            Log.e("Unity", "LocalLaunchManager getInstance error : " + stackTrace);
//            e.printStackTrace();
//        }
//
//
//
//        if (true) {
//            return;
//        }

        // 创建 HandlerThread
        HandlerThread handlerThread;
        handlerThread = new HandlerThread("ScreenCaptureThread");
        handlerThread.start();
        Handler handler = new Handler(handlerThread.getLooper());

        ImageReader imageReader;
        DisplayMetrics metrics = currentActivity.getResources().getDisplayMetrics();
        int width = Math.max(metrics.widthPixels, metrics.heightPixels);
        int height = Math.min(metrics.widthPixels, metrics.heightPixels);
        imageReader = ImageReader.newInstance(width, height, 0x1, 2);
        Surface surface = imageReader.getSurface();
        imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader reader) {
                Image image = reader.acquireLatestImage();
                if (image != null) {
                    Image.Plane[] planes = image.getPlanes();
                    ByteBuffer buffer = planes[0].getBuffer();
                    Log.d("Unity", "onImageAvailable: " + buffer.capacity());
                    image.close();
                }
            }
        }, handler);

        VirtualDisplay virtualDisplay = mediaProjection.createVirtualDisplay("ScreenCapture",
                width,
                height,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC | DisplayManager.VIRTUAL_DISPLAY_FLAG_SECURE | DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION,
                surface,
                null,
                null);

//        VirtualDisplay virtualDisplay = createVirtualDisplay(surface, width, height, metrics.densityDpi);
        Log.d("Unity", "virtualDisplay: " + virtualDisplay.getDisplay().getDisplayId());

        if (orderActivityInfo != null) {
            Log.d("Unity", "orderActivityInfo: " + orderActivityInfo.toString());
            ActivityInfo activityInfo = orderActivityInfo;
            Intent i = new Intent(Intent.ACTION_MAIN)
                    .setClassName(activityInfo.applicationInfo.packageName, activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ActivityOptions options = ActivityOptions.makeBasic();
            options.setLaunchDisplayId(virtualDisplay.getDisplay().getDisplayId());

            currentActivity.startActivity(i, options.toBundle());
        }

    }

    private static VirtualDisplay createVirtualDisplay(Surface surface, int width, int height, int densityDpi) {
//        {
//            currentActivity.runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    ImageReader imageReader;
//                    DisplayMetrics metrics = currentActivity.getResources().getDisplayMetrics();
//                    int width = Math.max(metrics.widthPixels, metrics.heightPixels);
//                    int heigh = Math.min(metrics.widthPixels, metrics.heightPixels);
//                    imageReader = ImageReader.newInstance(width, heigh, 0x1, 2);
//                    Surface surface = imageReader.getSurface();
//                    VirtualDisplay virtualDisplay = ((DisplayManager)currentActivity.getSystemService("display")).createVirtualDisplay("forbeampro-vd", 1920, 1080, metrics.densityDpi, surface, 0);
//                    Log.d("Unity", "virtualDisplay: " + virtualDisplay.getDisplay().getDisplayId());
//                }
//            });
//        }
        int flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC;
        VirtualDisplay virtualDisplay = ((DisplayManager)currentActivity.getSystemService("display")).createVirtualDisplay("forbeampro-vd", width, height, densityDpi, surface, flags);
        return virtualDisplay;
    }

    private static void requestScreenCapturePermission() {
        {
            currentActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String TAG = "ScreenCaptureRequestFragment";
                    FragmentManager fragmentManager = currentActivity.getFragmentManager();
                    com.pub.dou.ScreenCaptureRequestFragment fragment = (com.pub.dou.ScreenCaptureRequestFragment) fragmentManager.findFragmentByTag(TAG);

                    if (fragment == null) {
                        fragment = new com.pub.dou.ScreenCaptureRequestFragment();
                        fragmentManager.beginTransaction().add(fragment, TAG).commit();
                    }

                    fragmentManager.executePendingTransactions();
                    fragment.requirePermission();
                }
            });
        }

    }

    public static void launchActivityOnVirtualDisplay(Context context, String pkgName) {
        PackageManager pm = context.getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(pkgName);
        ActivityInfo orderActivityInfo = null;
        if (intent != null) {
            ResolveInfo resolveInfo = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
            orderActivityInfo = resolveInfo.activityInfo;
            String mainActivity = orderActivityInfo.name;
            String packageName = orderActivityInfo.packageName;
            Log.d("Unity", "MainActivity: " + mainActivity);
            Log.d("Unity", "PackageName: " + packageName);
        }
        Log.d("Unity", "intent: " + intent);
        Log.d("Unity", "createVitualDisplay: " + pkgName);

        if (orderActivityInfo == null) {
            return;
        }

        // 创建 HandlerThread
        HandlerThread handlerThread;
        handlerThread = new HandlerThread("ScreenCaptureThread");
        handlerThread.start();
        Handler handler = new Handler(handlerThread.getLooper());

        ImageReader imageReader;
        DisplayMetrics metrics = currentActivity.getResources().getDisplayMetrics();
        int width = Math.max(metrics.widthPixels, metrics.heightPixels);
        int height = Math.min(metrics.widthPixels, metrics.heightPixels);
        imageReader = ImageReader.newInstance(width, height, 0x1, 2);
        Surface surface = imageReader.getSurface();

        ImageListener imageListener = new ImageListener();
        imageReader.setOnImageAvailableListener(imageListener, handler);

        new Thread(()->{
            while (true) {
                imageListener.updateTexture(-1);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        Log.d("Unity", "orderActivityInfo packageName: " + orderActivityInfo.packageName);
        Log.d("Unity", "orderActivityInfo className: " + orderActivityInfo.name);

        try {
            reflectLaunchManager.requestLaunchActivityWithSurface(new ComponentName(orderActivityInfo.packageName, orderActivityInfo.name), width, height, surface);
        } catch (Exception e) {
            Log.e("Unity", "onServiceConnected error : " + exception2String(e));
        }
    }

    public static String exception2String(Exception e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }

    private static final class ImageListener implements ImageReader.OnImageAvailableListener {

        private ImageReader imageReader;
        private volatile boolean isNewAvailable = false;
        @Override
        public void onImageAvailable(ImageReader reader) {
            this.imageReader = reader;
            isNewAvailable = true;
        }
        public boolean updateTexture(int n) {
            Image image;
            boolean bl = this.isNewAvailable;
            if (bl) {
                image = imageReader.acquireLatestImage();
                if (image == null) {
                    Log.e("Unity", "updateTexture image is null");
                }
                this.isNewAvailable = false;
            } else {
                image = null;
            }
            if (image != null) {
                Log.d("Unity", "onImageAvailable: " + image);
                image.close();
                return true;
            }
            return false;
        }
    }
}
