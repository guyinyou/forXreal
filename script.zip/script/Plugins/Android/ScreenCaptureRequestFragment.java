package com.pub.dou;

import android.app.ActivityManager;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Surface;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.unity3d.player.UnityPlayer;

public class ScreenCaptureRequestFragment extends Fragment {

    private static final int REQUEST_MEDIA_PROJECTION = 506;
    private MediaProjectionManager mMediaProjectionManager;
    MediaProjection mMediaProjection;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void requirePermission() {
        // 初始化 MediaProjectionManager
        mMediaProjectionManager = (MediaProjectionManager) getActivity().getSystemService(MediaProjectionManager.class);
        // 请求录屏权限
        requestScreenCapturePermission();
    }

    private void requestScreenCapturePermission() {
        startActivityForResult(mMediaProjectionManager.createScreenCaptureIntent(), REQUEST_MEDIA_PROJECTION);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_MEDIA_PROJECTION) {
            if (resultCode == getActivity().RESULT_OK) {
                // 用户同意授权，获取 MediaProjection 实例
                mMediaProjection = mMediaProjectionManager.getMediaProjection(resultCode, data);
                Toast.makeText(getActivity(), "权限已获得，可以开始屏幕共享" + mMediaProjection, Toast.LENGTH_SHORT).show();


                // 创建 HandlerThread
                HandlerThread handlerThread;
                handlerThread = new HandlerThread("ScreenCaptureThread");
                handlerThread.start();
                Handler handler = new Handler(handlerThread.getLooper());

                ImageReader imageReader;
                DisplayMetrics metrics = getResources().getDisplayMetrics();
                int width = Math.max(metrics.widthPixels, metrics.heightPixels);
                int height = Math.min(metrics.widthPixels, metrics.heightPixels);
                imageReader = ImageReader.newInstance(width, height, 0x1, 2);
                Surface surface = imageReader.getSurface();
                imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                    @Override
                    public void onImageAvailable(ImageReader reader) {
                        Image image = reader.acquireLatestImage();
                        if (image != null) {
                            Image.Plane[] planes = image.getPlanes();
                            ByteBuffer buffer = planes[0].getBuffer();
                            Log.d("Unity", "onImageAvailable: " + buffer.capacity());
                            image.close();
                        }
                    }
                }, handler);
                VirtualDisplay virtualDisplay = mMediaProjection.createVirtualDisplay("ScreenCapture",
                        width,
                        height,
                        metrics.densityDpi,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC | DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION,
                        surface,
                        null,
                        null);
            } else {
                // 用户拒绝授权或操作失败，进行相应处理
                Toast.makeText(getActivity(), "权限被拒绝，无法进行屏幕共享", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void createVirtualDisplay(Surface surface, int screenWidth, int screenHeight, int dpi) {
        int flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION |
                DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC |
                DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY;

        VirtualDisplay mVirtualDisplay = mMediaProjection.createVirtualDisplay("ScreenCapture",
                screenWidth,
                screenHeight,
                dpi,
                flags,
                surface,
                null,
                null);
    }
}