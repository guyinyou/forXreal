package com.pub.dou;

import android.content.ComponentName;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.view.Surface;

public class ReflectLaunchManager {
    public static final String DESCRIPTOR = "ai.nreal.nebula.service.ILaunchManager";
    IBinder mRemote = null;
    public ReflectLaunchManager(IBinder mRemote) {
        this.mRemote = mRemote;
    }
    public void requestLaunchActivityWithSurface(ComponentName componentName, int n, int n2, Surface surface) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken(DESCRIPTOR);
            if (componentName != null) {
                parcel.writeInt(1);
                componentName.writeToParcel(parcel, 0);
            } else {
                parcel.writeInt(0);
            }
            parcel.writeInt(n);
            parcel.writeInt(n2);
            if (surface != null) {
                parcel.writeInt(1);
                surface.writeToParcel(parcel, 0);
            } else {
                parcel.writeInt(0);
            }
            if (!this.mRemote.transact(9, parcel, parcel2, 0)) {
//                return;
            }
            parcel2.readException();
            return;
        } finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }
    public void requestLaunchActivity(ComponentName componentName, int n, int n2) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken(DESCRIPTOR);
            if (componentName != null) {
                parcel.writeInt(1);
                componentName.writeToParcel(parcel, 0);
            } else {
                parcel.writeInt(0);
            }
            parcel.writeInt(n);
            parcel.writeInt(n2);
            if (!this.mRemote.transact(1, parcel, parcel2, 0)) {
//                return;
            }
            parcel2.readException();
            return;
        } finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }
}
