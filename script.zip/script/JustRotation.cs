using System;
using UnityEngine;
using System.Collections;
using System.Threading;
using NRKernal;

public class JustRotation : MonoBehaviour
{ 
    // 旋转速度
    public float rotationSpeed = 50f;

    void Start()
    {

    }
     void Update()
    {
        transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);
    }
}