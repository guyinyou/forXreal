using System;
using UnityEngine;
using System.Collections;
using System.Threading;
using NRKernal;
using System.Runtime.InteropServices;

public class Test : MonoBehaviour
{
    // Use this for initialization

    public Renderer imageRenderer;
    public GameObject imageRendererBackGround;

    private IntPtr byteBufferPtr;

    private Texture2D texture;

    private Thread thread;

    private bool isRunning = true;

    private LostTrackingReason m_LostTrackingReason = LostTrackingReason.INITIALIZING;
    void Start()
    {
        // Debug.Log("Application.runInBackground: " + Application.runInBackground);
        Application.runInBackground=true;
        // 获取 DirectByteBuffer 的地址
        AndroidJavaClass mainActivityClass = new AndroidJavaClass("com.pub.dou.Tools");
        bool ret = mainActivityClass.CallStatic<bool>("init");
        Debug.Log("init: " + ret);
        long directBufferAddress = mainActivityClass.GetStatic<long>("directBufferAddress");

        // 将地址转换为 IntPtr
        byteBufferPtr = new IntPtr(directBufferAddress);
        Debug.Log("get Address: " + directBufferAddress);

        // 创建 Texture2D 对象
        texture = new Texture2D(1920, 1080, TextureFormat.RGBA32, false);
        // 将 Texture2D 对象赋值给 Renderer 的材质
        imageRenderer.material.mainTexture = texture;

        // 创建新线程并开始执行函数
        thread = new Thread(ThreadFunction);
        thread.Start();
    }

    int cnt = 0;
    // Update is called once per frame
    void Update()
    {
        // Debug.Log("Application.isFocused: " + Application.isFocused);
        if (cnt++ >= 300)
        {
            Debug.Log("displays connected: " + Display.displays.Length);
            Display[] displays = Display.displays;
            for (int i = 0; i < displays.Length; i++)
            {
                Debug.Log("Display " + i + " - Width: " + displays[i].systemWidth + ", Height: " + displays[i].systemHeight);
            }
            cnt = 0;
        }
        // UpdateTexture();
    }
    bool updating = false;
    public void UpdateTexture() {
        // Debug.Log("Unity: updating - " + updating);
        int width = ReadInt32LittleEndian(byteBufferPtr);
        int height = ReadInt32LittleEndian(byteBufferPtr + 4);
        // width = 2297;
        // height = 1080;
        // Debug.Log("Unity: UpdateTexture - " + width + ", " + height);
        if(updating) {
            return;
        }
        updating = true;
        // 读取 DirectByteBuffer 中的图像数据
        byte[] imageData = ReadImageDataFromByteBuffer(byteBufferPtr + 8, width, height);
        if (texture.width != width || texture.height != height) {
            Destroy(texture);
            // 创建 Texture2D 对象
            texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
            // 将 Texture2D 对象赋值给 Renderer 的材质
            imageRenderer.material.mainTexture = texture;
            imageRenderer.transform.localScale = new Vector3(width, -height, 1);
            imageRendererBackGround.transform.localScale = new Vector3(width + 20, height + 20, 1);
        }
        // 更新 Texture2D 对象
        texture.LoadRawTextureData(imageData);
        texture.Apply();

        if(glassesRender != null) {
            UpdateRenderTexture(glassesRender);
        }
        updating = false;
    }
    // 从IntPtr读取小端整数
    public static int ReadInt32LittleEndian(IntPtr ptr)
    {
        // 确保内存对齐
        if (ptr == IntPtr.Zero || (ptr.ToInt64() & 0x3) != 0)
            throw new AccessViolationException("Memory not aligned.");
 
        // 读取小端整数
        byte[] bytes = new byte[4];
        Marshal.Copy(ptr, bytes, 0, 4);
        Array.Reverse(bytes); // 反转字节顺序以转换为小端
        return BitConverter.ToInt32(bytes, 0);
    }

    public RenderTexture glassesRender = null;

    public void UpdateRenderTexture(RenderTexture renderTexture) {
        Graphics.Blit(texture, renderTexture);
    }

    byte[] imageData = null;
    byte[] ReadImageDataFromByteBuffer(IntPtr bufferPtr, int width, int height)
    {
        if (imageData == null || imageData.Length != (width * height * 4))
        {
            imageData = new byte[width * height * 4];
        }
        System.Runtime.InteropServices.Marshal.Copy(bufferPtr, imageData, 0, imageData.Length);
        return imageData;
    }

    private void ThreadFunction()
    {
        int fps = 60;
        int duration = 1000 / fps;
        while (isRunning)
        {
            // UpdateTexture();
            Thread.Sleep(duration); // 延迟 1 秒钟
        }
    }

}