using UnityEngine;

[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
public class CurvedQuad : MonoBehaviour
{
    public int widthSegments = 10;  // 横向分段数
    public int heightSegments = 10; // 纵向分段数
    public float curveFactor = 0f;  // 曲率参数，正数为前，负数为后
    public float width = 1f;        // Quad的宽度
    public float height = 1f;       // Quad的高度

    private Mesh mesh;

    void Start()
    {
        mesh = new Mesh();
        GenerateMesh();
    }

    void Update()
    {
        // 根据曲率参数更新Mesh
        if (curveFactor != 0)
        {
            GenerateMesh(); // 曲率变化时重新生成Mesh
        }
    }

    void GenerateMesh()
    {
        int vertexCount = (widthSegments + 1) * (heightSegments + 1);
        Vector3[] vertices = new Vector3[vertexCount];
        Vector2[] uv = new Vector2[vertexCount];
        int[] triangles = new int[widthSegments * heightSegments * 6];

        // 生成顶点
        for (int x = 0; x <= widthSegments; x++)
        {
            for (int y = 0; y <= heightSegments; y++)
            {
                float u = (float)x / widthSegments; // 横向位置
                float v = (float)y / heightSegments; // 纵向位置

                float angle = (u - 0.5f) * Mathf.PI * curveFactor; // 曲率角度
                float xPos = Mathf.Sin(angle) * width; // 横向位置
                float zPos = curveFactor > 0 ? Mathf.Cos(angle) * (width / 2) : -Mathf.Cos(angle) * (width / 2); // 纵向位置

                int index = y + x * (heightSegments + 1);
                vertices[index] = new Vector3(xPos, (v - 0.5f) * height, zPos); // 顶点位置
                uv[index] = new Vector2(u, v);  // UV坐标
            }
        }

        // 生成三角形
        int t = 0;
        for (int x = 0; x < widthSegments; x++)
        {
            for (int y = 0; y <= heightSegments; y++)
            {
                int index = y + x * (heightSegments + 1);

                triangles[t++] = index;
                triangles[t++] = index + heightSegments + 1;
                triangles[t++] = index + 1;

                triangles[t++] = index + 1;
                triangles[t++] = index + heightSegments + 1;
                triangles[t++] = index + heightSegments + 2;
            }
        }

        mesh.vertices = vertices;
        mesh.uv = uv; // UV坐标，用于贴图
        mesh.triangles = triangles;
        mesh.RecalculateNormals(); // 重新计算法线
        mesh.RecalculateBounds(); // 重新计算边界

        GetComponent<MeshFilter>().mesh = mesh; // 设置Mesh
    }
}
