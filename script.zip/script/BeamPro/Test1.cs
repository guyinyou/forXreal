using System;
using UnityEngine;
using System.Collections;
using System.Threading;
using NRKernal;
using System.Runtime.InteropServices;

public class Test1 : MonoBehaviour
{
    // Use this for initialization

    public Renderer imageRenderer;
    public GameObject imageRendererBackGround;

    private IntPtr byteBufferPtr;

    private Texture2D texture;

    private Thread thread;

    private bool isRunning = true;

    private LostTrackingReason m_LostTrackingReason = LostTrackingReason.INITIALIZING;
    private AndroidJavaObject mediaProjection = null;
    void Start()
    {
        NRAndroidPermissionsManager.GetInstance().RequestAndroidPermission("android.permission.RECORD_AUDIO").ThenAction((requestResult) =>
        {
            if (requestResult.IsAllGranted)
            {
                NRAndroidPermissionsManager.GetInstance().RequestScreenCapture().ThenAction((AndroidJavaObject mediaProjection) => 
                {
                    if (mediaProjection != null)
                    {
                        this.mediaProjection = mediaProjection;
                        NRDebugger.Info("[VideoCapture] Screen capture is ok by user.");
                    }
                    else
                    {
                        NRDebugger.Error("[VideoCapture] Screen capture is denied by user.");
                    }
                });
            }
            else {
                NRDebugger.Error("[VideoCapture] Record audio need the permission of 'android.permission.RECORD_AUDIO'.");
            }
        });
        
        // AndroidJavaClass mainActivityClass = new AndroidJavaClass("com.pub.dou.Tools");
        // bool ret = mainActivityClass.CallStatic<bool>("init");
        // Debug.Log("init: " + ret);
    }

    public void createVitualDisplay(){
        AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

        // 获取 DirectByteBuffer 的地址
        AndroidJavaClass mainActivityClass = new AndroidJavaClass("com.pub.dou.Tools");
        mainActivityClass.CallStatic("startOnVirtualDisplay", activity, this.mediaProjection, "tv.danmaku.bilibilihd");
    }

    int cnt = 0;
    // Update is called once per frame
    void Update()
    {
        // Debug.Log("Application.isFocused: " + Application.isFocused);
        if (cnt++ >= 300)
        {
            Debug.Log("displays connected: " + Display.displays.Length);
            Display[] displays = Display.displays;
            for (int i = 0; i < displays.Length; i++)
            {
                Debug.Log("Display " + i + " - Width: " + displays[i].systemWidth + ", Height: " + displays[i].systemHeight);
            }
            cnt = 0;
        }
        // UpdateTexture();
    }
    bool updating = false;
    public void UpdateTexture() {
        // Debug.Log("Unity: updating - " + updating);
        int width = ReadInt32LittleEndian(byteBufferPtr);
        int height = ReadInt32LittleEndian(byteBufferPtr + 4);
        // width = 2297;
        // height = 1080;
        // Debug.Log("Unity: UpdateTexture - " + width + ", " + height);
        if(updating) {
            return;
        }
        updating = true;
        // 读取 DirectByteBuffer 中的图像数据
        byte[] imageData = ReadImageDataFromByteBuffer(byteBufferPtr + 8, width, height);
        if (texture.width != width || texture.height != height) {
            Destroy(texture);
            // 创建 Texture2D 对象
            texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
            // 将 Texture2D 对象赋值给 Renderer 的材质
            imageRenderer.material.mainTexture = texture;
            imageRenderer.transform.localScale = new Vector3(width, -height, 1);
            imageRendererBackGround.transform.localScale = new Vector3(width + 20, height + 20, 1);
        }
        // 更新 Texture2D 对象
        texture.LoadRawTextureData(imageData);
        texture.Apply();

        if(glassesRender != null) {
            UpdateRenderTexture(glassesRender);
        }
        updating = false;
    }
    // 从IntPtr读取小端整数
    public static int ReadInt32LittleEndian(IntPtr ptr)
    {
        // 确保内存对齐
        if (ptr == IntPtr.Zero || (ptr.ToInt64() & 0x3) != 0)
            throw new AccessViolationException("Memory not aligned.");
 
        // 读取小端整数
        byte[] bytes = new byte[4];
        Marshal.Copy(ptr, bytes, 0, 4);
        Array.Reverse(bytes); // 反转字节顺序以转换为小端
        return BitConverter.ToInt32(bytes, 0);
    }

    public RenderTexture glassesRender = null;

    public void UpdateRenderTexture(RenderTexture renderTexture) {
        Graphics.Blit(texture, renderTexture);
    }

    byte[] imageData = null;
    byte[] ReadImageDataFromByteBuffer(IntPtr bufferPtr, int width, int height)
    {
        if (imageData == null || imageData.Length != (width * height * 4))
        {
            imageData = new byte[width * height * 4];
        }
        System.Runtime.InteropServices.Marshal.Copy(bufferPtr, imageData, 0, imageData.Length);
        return imageData;
    }

}